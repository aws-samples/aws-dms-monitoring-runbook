import boto3
import json
import os

# Initialize CloudWatch and DMS clients
cloudwatch_client = boto3.client('cloudwatch')
dms_client = boto3.client('dms')

def get_dms_instances():
    instances = []
    paginator = dms_client.get_paginator('describe_replication_instances')
    
    for page in paginator.paginate():
        instances.extend(page['ReplicationInstances'])
    
    return instances

def create_dashboard_body(instances, metrics):
    widgets = []
    
    for metric in metrics:
        metric_widget = {
            'type': 'metric',
            'x': 0,
            'y': len(widgets) * 6,
            'width': 24,
            'height': 6,
            'properties': {
                'metrics': [],
                'view': 'timeSeries',
                'stacked': False,
                'region': os.getenv('AWS_REGION', 'us-east-1'),
                'title': f'{metric} ',
                'period': 300
            }
        }

        for instance in instances:
            instance_name = instance['ReplicationInstanceIdentifier']
            metric_widget['properties']['metrics'].append(
                [
                    'AWS/DMS',
                    metric,
                    'ReplicationInstanceIdentifier', instance_name
                ]
            )

        widgets.append(metric_widget)
    
    dashboard_body = {
        'widgets': widgets
    }
    
    return json.dumps(dashboard_body)

def create_cloudwatch_dashboard(dashboard_body):
    dashboard_name = 'DMS_Instances_Dashboard'
    
    cloudwatch_client.put_dashboard(
        DashboardName=dashboard_name,
        DashboardBody=dashboard_body
    )
    print(f"Dashboard '{dashboard_name}' created/updated successfully.")

def lambda_handler(event, context):
    # Retrieve metrics from environment variable or default to specific metrics
    metrics_input = os.getenv('CLOUDWATCH_METRICS', 'CPUUtilization,SwapUsage,FreeableMemory')
    metrics = [metric.strip() for metric in metrics_input.split(',')]
    
    instances = get_dms_instances()
    dashboard_body = create_dashboard_body(instances, metrics)
    create_cloudwatch_dashboard(dashboard_body)

# If running this script directly, call the handler function.
if __name__ == "__main__":
    lambda_handler(None, None)

