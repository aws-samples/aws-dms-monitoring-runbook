import json
import boto3
import os

# Initialize Boto3 clients
dms_client = boto3.client('dms')
cloudwatch_client = boto3.client('cloudwatch')

# Alarm settings
CPU_THRESHOLD = os.getenv('CPU_THRESHOLD',80) # CPUUtilization > 80% or custom value specified in parameter.
MEMORY_THRESHOLD = os.getenv('MEMORY_THRESHOLD',25)  # FreeableMemory < 25% or custom value specified in parameter.
SWAP_THRESHOLD = os.getenv('SWAP_THRESHOLD',25)  # SwapUsage > 25% or custom value specified in parameter.
CAPACITY_THRESHOLD = os.getenv('CAPACITY_THRESHOLD',75)  # CapacityUtilization > 75% or custom value specified in parameter.
ALARM_PERIOD = 300  # Period in seconds (5 minutes)
ALARM_EVALUATION_PERIODS = 1
ALARM_NAMESPACE = 'AWS/DMS'

SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')

def get_all_dms_instances():
    response = dms_client.describe_replication_instances()
    return response['ReplicationInstances']

def get_all_dms_tasks():
    response = dms_client.describe_replication_tasks()
    return response['ReplicationTasks']

def get_all_replication_configs():
    response = dms_client.describe_replication_configs()
    return response['ReplicationConfigs']

def create_cloudwatch_alarm(resource_id, metric_name, threshold, comparison_operator, statistic, dimensions):
    cloudwatch_client.put_metric_alarm(
        AlarmName=f'{resource_id}-{metric_name}-Alarm',
        AlarmDescription=f'Alarm for {metric_name} of DMS resource {resource_id}',
        MetricName=metric_name,
        Namespace=ALARM_NAMESPACE,
        Statistic=statistic,
        Dimensions=dimensions,
        Period=ALARM_PERIOD,
        EvaluationPeriods=ALARM_EVALUATION_PERIODS,
        Threshold=threshold,
        ComparisonOperator=comparison_operator,
        AlarmActions=[
            SNS_TOPIC_ARN
        ]
    )

def lambda_handler(event, context):
    # Create alarms for DMS instances
    if not SNS_TOPIC_ARN:
        print("SNS_TOPIC_ARN environment variable is not set. Exiting.")
        return {
           "statusCode": 400,
          "body": "SNS_TOPIC_ARN environment variable is not set."
    
        }
    instances = get_all_dms_instances()
    
    for instance in instances:
        instance_id = instance['ReplicationInstanceIdentifier']
        
        # Create alarms with specified thresholds
        create_cloudwatch_alarm(instance_id, 'CPUUtilization', int(CPU_THRESHOLD), 'GreaterThanThreshold', 'Average', [
            {
                'Name': 'ReplicationInstanceIdentifier',
                'Value': instance_id
            }
        ])
        create_cloudwatch_alarm(instance_id, 'FreeableMemory', int(MEMORY_THRESHOLD), 'LessThanThreshold', 'Average', [
            {
                'Name': 'ReplicationInstanceIdentifier',
                'Value': instance_id
            }
        ])
        create_cloudwatch_alarm(instance_id, 'SwapUsage', int(SWAP_THRESHOLD), 'GreaterThanThreshold', 'Average', [
            {
                'Name': 'ReplicationInstanceIdentifier',
                'Value': instance_id
            }
        ])
    
    # Create alarms for DMS Serverless tasks
    tasks = get_all_dms_tasks()
    for task in tasks:
        task_id = task['ReplicationTaskIdentifier']
        task_arn = task['ReplicationTaskArn']
        
        if task.get('TaskType') == 'serverless':
            create_cloudwatch_alarm(task_id, 'CapacityUtilization', int(CAPACITY_THRESHOLD), 'GreaterThanThreshold', 'Average', [
                {
                    'Name': 'ReplicationTaskArn',
                    'Value': task_arn
                }
            ])

    # Create alarms for Replication Configs (for Serverless DMS)
    configs = get_all_replication_configs()
    for config in configs:
        
        arn_parts = config['ReplicationConfigArn'].split(':')
        account_number = arn_parts[4]
        resource_id = arn_parts[6] 
        config_id = account_number+':'+resource_id
        
        create_cloudwatch_alarm(config_id, 'CapacityUtilization', int(CAPACITY_THRESHOLD), 'GreaterThanThreshold', 'Average', [
            {
                'Name': 'ReplicationConfigId',
                'Value': config_id
            }
        ])
    
    return {
        'statusCode': 200,
        'body': json.dumps('CloudWatch alarms created successfully for all DMS instances, Serverless tasks, and Replication Configs.')
    }

