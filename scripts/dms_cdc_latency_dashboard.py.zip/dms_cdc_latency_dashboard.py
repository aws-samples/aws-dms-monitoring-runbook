import boto3
import json
import os

# Initialize CloudWatch and DMS clients
cloudwatch_client = boto3.client('cloudwatch')
dms_client = boto3.client('dms')

def get_dms_tasks():
    tasks = []
    paginator = dms_client.get_paginator('describe_replication_tasks')
    
    for page in paginator.paginate():
        tasks.extend(page['ReplicationTasks'])
    
    return tasks

def get_instance_name_map():
    instance_name_map = {}
    paginator = dms_client.get_paginator('describe_replication_instances')
    
    for page in paginator.paginate():
        for instance in page['ReplicationInstances']:
            instance_arn = instance['ReplicationInstanceArn']
            instance_name = instance['ReplicationInstanceIdentifier']
            instance_name_map[instance_arn] = instance_name
    
    return instance_name_map

def create_dashboard_body(instance_name, tasks, metrics):
    widgets = []
    
    for task in tasks:
        task_id = task['ReplicationTaskIdentifier']
        
        for metric in metrics:
            # Widget for each metric
            widgets.append({
                'type': 'metric',
                'x': 0,
                'y': len(widgets) * 6,
                'width': 24,
                'height': 6,
                'properties': {
                    'metrics': [
                        [
                            '/aws/dms/replication_instance',
                            metric,
                            'ReplicationTaskIdentifier', task_id,
                            'ReplicationInstanceIdentifier', instance_name
                        ]
                    ],
                    'view': 'timeSeries',
                    'stacked': False,
                    'region': os.getenv('AWS_REGION', 'us-east-1'),
                    'title': f'{metric} for {task_id}',
                    'period': 300
                }
            })
    
    dashboard_body = {
        'widgets': widgets
    }
    
    return json.dumps(dashboard_body)

def create_cloudwatch_dashboard(instance_name, dashboard_body):
    dashboard_name = f'DMS_CDC_Latency_Dashboard_{instance_name}'
    
    cloudwatch_client.put_dashboard(
        DashboardName=dashboard_name,
        DashboardBody=dashboard_body
    )
    print(f"Dashboard '{dashboard_name}' created/updated successfully.")

def lambda_handler(event, context):
    metrics_input = os.getenv('CLOUDWATCH_METRICS', 'CDCSourceLatency,CDCLatencyTarget')
    metrics = [metric.strip() for metric in metrics_input.split(',')]
    
    tasks = get_dms_tasks()
    instance_name_map = get_instance_name_map()
    
    # Group tasks by replication instance name
    instance_tasks = {}
    for task in tasks:
        instance_arn = task['ReplicationInstanceArn']
        instance_name = instance_name_map[instance_arn]
        if instance_name not in instance_tasks:
            instance_tasks[instance_name] = []
        instance_tasks[instance_name].append(task)
    
    # Create a separate dashboard for each instance
    for instance_name, tasks in instance_tasks.items():
        dashboard_body = create_dashboard_body(instance_name, tasks, metrics)
        create_cloudwatch_dashboard(instance_name, dashboard_body)

# If running this script directly, call the handler function.
if __name__ == "__main__":
    lambda_handler(None, None)

