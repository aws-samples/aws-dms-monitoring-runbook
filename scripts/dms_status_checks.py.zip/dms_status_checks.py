import json
import boto3
import os

# Initialize Boto3 clients
dms_client = boto3.client('dms')
sns_client = boto3.client('sns')

# Replace with your SNS Topic ARN
SNS_TOPIC_ARN = os.getenv('SNS_TOPIC_ARN')
EXCLUDE_INSTANCES = os.getenv('EXCLUDE_INSTANCES','').split(',')
EXCLUDE_TASKS = os.getenv('EXCLUDE_TASKS','').split(',')

def get_all_dms_instances():
    instances = []
    paginator = dms_client.get_paginator('describe_replication_instances')
    for page in paginator.paginate():
        instances.extend(page['ReplicationInstances'])
    return instances

def get_all_dms_tasks():
    tasks = []
    paginator = dms_client.get_paginator('describe_replication_tasks')
    for page in paginator.paginate():
        tasks.extend(page['ReplicationTasks'])
    return tasks

def check_instance_public_access(instance_arn):
    response = dms_client.describe_replication_instances(
        Filters=[{'Name': 'replication-instance-arn', 'Values': [instance_arn]}]
    )
    instance = response['ReplicationInstances'][0]
    return instance.get('PubliclyAccessible', False)

def get_instance_tasks(instance_arn):
    tasks = []
    paginator = dms_client.get_paginator('describe_replication_tasks')
    for page in paginator.paginate(Filters=[{'Name': 'replication-instance-arn', 'Values': [instance_arn]}]):
        tasks.extend(page['ReplicationTasks'])
    return tasks

def dms_tasks_active(tasks):
    for task in tasks:
        status = task['Status']
        if status in ['Creating', 'Running','Stopping', 'Error','Creating', 'Running with errors','Starting', 'Modifying', 'Testing']:
            return True
    return False

def get_debug_logging_tasks():
    tasks_with_debug_logging = []
    tasks = get_all_dms_tasks()
    for task in tasks:
        if task['ReplicationTaskIdentifier'] in EXCLUDE_TASKS:
            print('skipping DMS Task from debug logging checks:' +task['ReplicationTaskIdentifier'])
            continue
        
        settings = task.get('ReplicationTaskSettings', '{}')
        if 'LOGGER_SEVERITY_DEBUG' in settings or 'LOGGER_SEVERITY_DETAILED_DEBUG' in settings:
            tasks_with_debug_logging.append({
                'ReplicationTaskIdentifier': task['ReplicationTaskIdentifier'],
                'ReplicationTaskArn': task['ReplicationTaskArn']
            })
    return tasks_with_debug_logging

def send_sns_notification(message):
    
    sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message= message,
        Subject=f"AWS DMS Alerts!",
    )

def lambda_handler(event, context):
    if not SNS_TOPIC_ARN:
        print("SNS_TOPIC_ARN environment variable is not set. Exiting.")
        return {
            "statusCode": 400,
            "body": "SNS_TOPIC_ARN environment variable is not set."
            
        }
    
    notifications = []
    
    instances = get_all_dms_instances()
    
    for instance in instances:
        instance_arn = instance['ReplicationInstanceArn']
        instance_name = instance['ReplicationInstanceIdentifier']
        if instance_name in EXCLUDE_INSTANCES:
            print('skipping DMS Instance:' +instance['ReplicationInstanceIdentifier'])
            continue
        public_access = check_instance_public_access(instance_arn)
        try:
            tasks = get_instance_tasks(instance_arn)
            if not dms_tasks_active(tasks):
                notifications.append(f"AWS DMS instance is running idle and NO active DMS task found! \n - [{instance_name}]  [{instance_arn}] ")
                notifications.append("Recommended Action: You may save cost by removing DMS Instances that are no longer required.")
                notifications.append("\n")  # Paragraph separator
        except:
            notifications.append(f"AWS DMS instance is runninng idle and has NO DMS task associated with it! \n - [{instance_name}] [{instance_arn}] ")
            notifications.append("Recommended Action: You may save cost by removing DMS Instances that are no longer required or moving to DMS Serverless.")
            notifications.append("\n")  # Paragraph separator
        
        if public_access:
            notifications.append(f"AWS DMS instance has public access enabled !\n - [{instance_name}]  [{instance_arn}] ")
            notifications.append("Recommended Action: It is security best practice to disable public access from all AWS DMS instances. ")
            notifications.append("\n")  # Paragraph separator
            
            
    
    debug_logging_tasks = get_debug_logging_tasks()
    if debug_logging_tasks:
        debug_logging_message = "DMS tasks with debug logging enabled:\n"
        debug_logging_message += "\n".join([f"- {task['ReplicationTaskIdentifier']}: {task['ReplicationTaskArn']}" for task in debug_logging_tasks])
        notifications.append(debug_logging_message)
        notifications.append("Recommended Action: It is recommended to enable DMS task debug logging only for the short duration for troubleshooting. Keeping debug logging enabled for longer period of time may impact DMS replication instance performance. It may also fill up the storage quickly and impact all of the task running on the same DMS instance.")
        notifications.append("\n")  # Paragraph separator
    
    if notifications:
        full_message = "\n".join(notifications)
        send_sns_notification(full_message)
        print(f"Sent notification: {full_message}")

    return {
        'statusCode': 200,
        'body': json.dumps('Lambda function executed successfully!')
    }

