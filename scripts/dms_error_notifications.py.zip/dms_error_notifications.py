import boto3
import os
import re
from datetime import datetime, timedelta

logs_client = boto3.client('logs')
sns_client = boto3.client('sns')

# Environment variables
SNS_TOPIC_ARN = os.environ.get('SNS_TOPIC_ARN')
LOG_GROUP_PATTERN = os.environ.get('LOG_GROUP_PATTERN', 'dms-*')
EXCLUDED_LOG_STREAMS = os.environ.get('EXCLUDED_LOG_STREAMS', '').split(',')
filter_pattern = os.environ.get('FILTER_PATTERN','?ERROR ?WARNING ?error ?warning')  # Filter pattern for errors and warnings in selected LogGroups

def lambda_handler(event, context):
    if not SNS_TOPIC_ARN:
        print("SNS_TOPIC_ARN environment variable is not set. Exiting.")
        return {
            "statusCode": 400,
            "body": "SNS_TOPIC_ARN environment variable is not set."
        
    }
    end_time = int(datetime.now().timestamp() * 1000) # Current time in milliseconds
    start_time = int((datetime.now() - timedelta(minutes=60)).timestamp() * 1000) # 60 minutes ago

    # Get all log groups matching the pattern
    log_groups = get_matching_log_groups(LOG_GROUP_PATTERN)
    for log_group in log_groups:
        # Get all log streams within the log group
        log_streams = logs_client.describe_log_streams(
            logGroupName=log_group,
            orderBy='LastEventTime',
            descending=True
        )['logStreams']
        
        for log_stream in log_streams:
            log_stream_name = log_stream['logStreamName']
            
            # Skip excluded log streams
            if log_stream_name in EXCLUDED_LOG_STREAMS:
                print('skipping log stream:' +log_stream_name)
                continue
            # Filter log events in the log stream for errors and warnings
            events = logs_client.filter_log_events(
                logGroupName=log_group,
                logStreamNames=[log_stream_name],
                startTime=start_time,
                endTime=end_time,
                filterPattern=filter_pattern
            )['events']
            
            if events:
                message = create_message(log_group, log_stream_name, events)
               
                send_notification(SNS_TOPIC_ARN, message)

def get_matching_log_groups(pattern):
    log_groups = []
    paginator = logs_client.get_paginator('describe_log_groups')
    for page in paginator.paginate(logGroupNamePrefix=pattern.rstrip('*')):
        for log_group in page['logGroups']:
            log_groups.append(log_group['logGroupName'])
    return log_groups

def create_message(log_group, log_stream_name, events):
    event_messages = '\n'.join(event['message'] for event in events)
    message = (f"Matched events in log group: {log_group}, log stream: {log_stream_name}\n"
               f"Events:\n{event_messages}")
    return message

def send_notification(topic_arn, message):
    sns_client.publish(
        TopicArn=topic_arn,
        Message=message,
        Subject='AWS DMS Log Alert'
    )
